package bank;

public class DeleteRequests {
}
